Shakespeare
=====================
Sonnet 31
---------------
Thy bosom is endeared with all hearts,
Which I by lacking have supposed dead;
And there reigns Love, and all Love's loving parts,
And all those friends which I thought buried.
How many a holy and obsequious tear
Hath dear religious love stol'n from mine eye,
As interest of the dead, which now appear
But things remov'd that hidden in thee lie!
Thou art the grave where buried love doth live,
Hung with the trophies of my lovers gone,
Who all their parts of me to thee did give,
That due of many now is thine alone:
Their images I lov'd, I view in thee,
And thou—all they—hast all the all of me.