Shakespeare
=====================
Sonnet 28
---------------
How can I then return in happy plight,
That am debarre'd the benefit of rest?
When day's oppression is not eas'd by night,
But day by night and night by day oppress'd,
And each, though enemies to either's reign,
Do in consent shake hands to torture me,
The one by toil, the other to complain
How far I toil, still farther off from thee.
I tell the day, to please him thou art bright,
And dost him grace when clouds do blot the heaven:
So flatter I the swart-complexion'd night,
When sparkling stars twire not thou gild'st the even.
But day doth daily draw my sorrows longer,
And night doth nightly make grief's length seem stronger.

EDITED