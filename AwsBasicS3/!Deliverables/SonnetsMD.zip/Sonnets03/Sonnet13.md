Shakespeare
=====================
Sonnet 13
---------------
O! that you were your self; but, love you are
No longer yours, than you your self here live:
Against this coming end you should prepare,
And your sweet semblance to some other give:
So should that beauty which you hold in lease
Find no determination; then you were
Yourself again, after yourself's decease,
When your sweet issue your sweet form should bear.
Who lets so fair a house fall to decay,
Which husbandry in honour might uphold,
Against the stormy gusts of winter's day
And barren rage of death's eternal cold?
O! none but unthrifts. Dear my love, you know,
You had a father: let your son say so.