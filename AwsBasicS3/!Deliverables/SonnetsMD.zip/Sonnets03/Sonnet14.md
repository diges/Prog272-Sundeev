Shakespeare
=====================
Sonnet 14
---------------
Not from the stars do I my judgement pluck;
And yet methinks I have astronomy,
But not to tell of good or evil luck,
Of plagues, of dearths, or seasons' quality;
Nor can I fortune to brief minutes tell,
Pointing to each his thunder, rain and wind,
Or say with princes if it shall go well
By oft predict that I in heaven find:
But from thine eyes my knowledge I derive,
And constant stars in them I read such art
As 'Truth and beauty shall together thrive,
If from thyself, to store thou wouldst convert';
Or else of thee this I prognosticate:
'Thy end is truth's and beauty's doom and date.'